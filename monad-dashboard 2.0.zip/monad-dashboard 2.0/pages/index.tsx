// pages/index.tsx
import React from 'react';
import TransactionsChart from '../components/TransactionsChart';
import ContractUsageChart from '../components/ContractUsageChart';
import LatestTransactions from '../components/LatestTransactions';
import ThemeToggle from '../components/ThemeToggle';
import mockData from '../mockData';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-primary dark:bg-gradient-primary relative overflow-hidden">
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/20 dark:to-black/40"></div>
      
      {/* Theme Toggle */}
      <ThemeToggle />
      
      {/* Main Content */}
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white dark:text-white mb-2">
            Monad Dashboard
          </h1>
          <p className="text-primary-200 dark:text-primary-300 text-lg">
            Real-time blockchain analytics and insights
          </p>
        </div>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-2">
                Total Transactions
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-3xl">
                {mockData.stats.totalTransactions.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-2">
                Active Wallets
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-3xl">
                {mockData.stats.activeWallets.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-2">
                24h Volume
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-3xl">
                ${mockData.stats.tokenVolume24h.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Secondary Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-lg mb-2">
                Gas Used Today
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-2xl">
                {mockData.stats.gasUsedToday.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-lg mb-2">
                Block Time
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-2xl">
                {mockData.stats.blockTime}
              </p>
            </div>
          </div>

          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <h2 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-lg mb-2">
                Total Blocks
              </h2>
              <p className="stat-value stat-value-dark dark:stat-value-dark stat-value-light text-2xl">
                {mockData.stats.totalBlocks.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <TransactionsChart data={mockData.transactionsPerDay} />
            </div>
          </div>
          <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
            <div className="p-6">
              <ContractUsageChart data={mockData.contractUsage} />
            </div>
          </div>
        </div>

        {/* Latest Transactions */}
        <div className="dashboard-card dashboard-card-dark dark:dashboard-card-dark dashboard-card-light">
          <div className="p-6">
            <LatestTransactions data={mockData.latestTransactions} />
          </div>
        </div>
      </div>
    </div>
  );
}
