// components/LatestTransactions.tsx
import React from 'react';

type Transaction = {
  hash: string;
  from: string;
  to: string;
  amount: string;
  time: string;
};

export default function LatestTransactions({ data }: { data: Transaction[] }) {
  return (
    <div>
      <h3 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-6">
        Latest Transactions
      </h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-primary/20 dark:border-primary/30">
              <th className="py-4 px-3 text-left stat-label stat-label-dark dark:stat-label-dark stat-label-light font-medium">
                Hash
              </th>
              <th className="py-4 px-3 text-left stat-label stat-label-dark dark:stat-label-dark stat-label-light font-medium">
                From
              </th>
              <th className="py-4 px-3 text-left stat-label stat-label-dark dark:stat-label-dark stat-label-light font-medium">
                To
              </th>
              <th className="py-4 px-3 text-left stat-label stat-label-dark dark:stat-label-dark stat-label-light font-medium">
                Amount
              </th>
              <th className="py-4 px-3 text-left stat-label stat-label-dark dark:stat-label-dark stat-label-light font-medium">
                Time
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map((tx, idx) => (
              <tr 
                key={idx} 
                className="border-b border-primary/10 dark:border-primary/20 hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors duration-200"
              >
                <td className="py-4 px-3 font-mono text-xs truncate max-w-[140px] stat-value stat-value-dark dark:stat-value-dark stat-value-light">
                  {tx.hash}
                </td>
                <td className="py-4 px-3 font-mono text-xs truncate max-w-[140px] stat-value stat-value-dark dark:stat-value-dark stat-value-light">
                  {tx.from}
                </td>
                <td className="py-4 px-3 font-mono text-xs truncate max-w-[140px] stat-value stat-value-dark dark:stat-value-dark stat-value-light">
                  {tx.to}
                </td>
                <td className="py-4 px-3 font-medium text-green-400 dark:text-green-300">
                  {tx.amount}
                </td>
                <td className="py-4 px-3 text-primary-400 dark:text-primary-300">
                  {tx.time}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
