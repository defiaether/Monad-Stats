// components/TransactionsChart.tsx
import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { useTheme } from './useTheme';

type TransactionData = {
  date: string;
  count: number;
};

export default function TransactionsChart({ data }: { data: TransactionData[] }) {
  const isDark = useTheme();
  
  return (
    <div>
      <h3 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-6">
        Transactions per Day
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <XAxis 
            dataKey="date" 
            stroke={isDark ? "#836EF9" : "#6B46C1"}
            fontSize={12}
            tick={{ fill: isDark ? "#E2E8F0" : "#374151" }}
          />
          <YAxis 
            stroke={isDark ? "#836EF9" : "#6B46C1"}
            fontSize={12}
            tick={{ fill: isDark ? "#E2E8F0" : "#374151" }}
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: isDark ? 'rgba(32, 0, 82, 0.9)' : 'rgba(255, 255, 255, 0.95)',
              border: `1px solid ${isDark ? 'rgba(131, 110, 249, 0.3)' : 'rgba(131, 110, 249, 0.2)'}`,
              borderRadius: '12px',
              color: isDark ? 'white' : '#111',
              backdropFilter: 'blur(10px)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
            }}
          />
          <Line 
            type="monotone" 
            dataKey="count" 
            stroke="#836EF9" 
            strokeWidth={3}
            dot={{ 
              fill: '#836EF9', 
              strokeWidth: 2, 
              r: 5,
              stroke: isDark ? '#200052' : '#FFFFFF'
            }}
            activeDot={{ 
              r: 8, 
              stroke: '#836EF9', 
              strokeWidth: 2,
              fill: isDark ? '#200052' : '#FFFFFF'
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
