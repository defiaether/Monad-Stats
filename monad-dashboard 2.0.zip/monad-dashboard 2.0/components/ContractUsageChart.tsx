// components/ContractUsageChart.tsx
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { useTheme } from './useTheme';

type ContractData = {
  name: string;
  value: number;
};

const COLORS = ['#836EF9', '#10B981', '#F59E0B', '#EF4444'];

export default function ContractUsageChart({ data }: { data: ContractData[] }) {
  const isDark = useTheme();
  
  return (
    <div>
      <h3 className="stat-label stat-label-dark dark:stat-label-dark stat-label-light text-xl mb-6">
        Contract Usage %
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            outerRadius={80}
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            labelLine={false}
          >
            {data.map((_, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{
              backgroundColor: isDark ? 'rgba(32, 0, 82, 0.9)' : 'rgba(255, 255, 255, 0.95)',
              border: `1px solid ${isDark ? 'rgba(131, 110, 249, 0.3)' : 'rgba(131, 110, 249, 0.2)'}`,
              borderRadius: '12px',
              color: isDark ? 'white' : '#111',
              backdropFilter: 'blur(10px)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
            }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
