// components/StatCard.tsx
import React from 'react';

type StatCardProps = {
  title: string;
  value: string | number;
};

export default function StatCard({ title, value }: StatCardProps) {
  return (
    <div className="bg-white dark:bg-zinc-900 shadow-md rounded-xl p-4 w-full text-center">
      <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
      <h2 className="text-2xl font-bold text-zinc-800 dark:text-white">{value}</h2>
    </div>
  );
}
